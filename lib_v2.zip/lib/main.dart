import 'package:bigbus/boarding.dart';
import 'package:bigbus/droping.dart';
import 'package:bigbus/from.dart';
import 'package:bigbus/home.dart';
import 'package:bigbus/search.dart';
import 'package:bigbus/seat.dart';
import 'package:bigbus/splash.dart';
import 'package:flutter/material.dart';

import 'calendar.dart';

Future<void> main() async {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      initialRoute: 'Splash',
      routes: {
        'Splash': (context) => const Home(),
      },
    );
  }
}
