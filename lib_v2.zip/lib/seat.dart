import 'package:bigbus/boarding.dart';
import 'package:bigbus/home.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';

class Seat extends StatefulWidget {
  const Seat({super.key});

  @override
  State<Seat> createState() => _SeatState();
}

class _SeatState extends State<Seat> {
  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff4A9DFF),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
        body: SafeArea(
            child: Stack(
      children: [
        Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          color: const Color(0xffEFF3F8),
          child: Column(children: [
            Container(
                width: MediaQuery.of(context).size.width,
                height: 80,
                color: const Color(0xff4A9DFF),
                alignment: Alignment.center,
                child: Row(
                  children: [
                    const SizedBox(
                      width: 10,
                    ),
                    InkWell(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: SvgPicture.asset(
                        'assets/back.svg',
                        width: 30,
                        fit: BoxFit.fill,
                      ),
                    ),
                    const SizedBox(
                      width: 10,
                    ),
                    const Text(
                      "Select your seat",
                      style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          fontFamily: "Bold",
                          color: Colors.white),
                    ),
                  ],
                )),
            Container(
              width: MediaQuery.of(context).size.width,
              color: Colors.white,
              padding: const EdgeInsets.all(12),
              margin: const EdgeInsets.only(top: 10),
              child: Column(children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      "Humsafar Travels",
                      style: TextStyle(
                          fontSize: 15,
                          color: Color(0xff000E2B),
                          fontFamily: "Bold"),
                    ),
                    Container(
                      padding: const EdgeInsets.only(
                          left: 5, right: 5, top: 2, bottom: 2),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          color: const Color(0xff0FBC00)),
                      child: Row(
                        children: [
                          Container(
                            width: 13,
                            alignment: Alignment.center,
                            child: SvgPicture.asset(
                              'assets/rating.svg',
                              width: 13,
                              fit: BoxFit.fill,
                            ),
                          ),
                          const SizedBox(
                            width: 3,
                          ),
                          const Text(
                            "4/5",
                            style: TextStyle(
                                fontSize: 13,
                                color: Colors.white,
                                fontFamily: "Bold"),
                          ),
                        ],
                      ),
                    )
                  ],
                ),
                const SizedBox(
                  height: 5,
                ),
                Row(
                  children: const [
                    Text(
                      "A/C Sleeper(2+1)",
                      style: TextStyle(
                          fontSize: 13,
                          color: Color(0xff5C5C5C),
                          fontFamily: "Medium"),
                    ),
                    SizedBox(
                      width: 5,
                    ),
                    Text(
                      "9 Seat Left",
                      style: TextStyle(
                          fontSize: 13,
                          color: Color(0xffFF7979),
                          fontFamily: "Bold"),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 15,
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const Text(
                      "07:30PM",
                      style: TextStyle(
                          fontSize: 15,
                          color: Color(0xff000E2B),
                          fontFamily: "Medium"),
                    ),
                    const SizedBox(
                      width: 5,
                    ),
                    Column(
                      children: [
                        const Text(
                          "1h 35m",
                          style: TextStyle(
                              fontSize: 10,
                              color: Color(0xff5C5C5C),
                              fontFamily: "Medium"),
                        ),
                        Container(
                          width: 50,
                          alignment: Alignment.center,
                          child: SvgPicture.asset(
                            'assets/path.svg',
                            width: 50,
                          ),
                        ),
                        const SizedBox(
                          height: 11,
                        ),
                      ],
                    ),
                    const SizedBox(
                      width: 5,
                    ),
                    const Text(
                      "07:30PM",
                      style: TextStyle(
                          fontSize: 15,
                          color: Color(0xff000E2B),
                          fontFamily: "Medium"),
                    ),
                  ],
                ),
              ]),
            ),
            const SizedBox(
              height: 15,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Row(
                  children: [
                    Container(
                      width: 25,
                      height: 25,
                      decoration: BoxDecoration(
                          color: Colors.white,
                          border: Border.all(
                              width: 1, color: const Color(0xff848484))),
                    ),
                    const SizedBox(
                      width: 5,
                    ),
                    const Text(
                      "Aavailable",
                      style: TextStyle(
                          fontSize: 10,
                          color: Color(0xff5C5C5C),
                          fontFamily: "Medium"),
                    ),
                  ],
                ),
                Row(
                  children: [
                    Container(
                      width: 25,
                      height: 25,
                      decoration: BoxDecoration(
                          color: const Color(0xff3E3E3E),
                          border: Border.all(
                              width: 1, color: const Color(0xff3E3E3E))),
                    ),
                    const SizedBox(
                      width: 5,
                    ),
                    const Text(
                      "Booked",
                      style: TextStyle(
                          fontSize: 10,
                          color: Color(0xff5C5C5C),
                          fontFamily: "Medium"),
                    ),
                  ],
                ),
                Row(
                  children: [
                    Container(
                      width: 25,
                      height: 25,
                      decoration: BoxDecoration(
                          color: const Color(0xffFF3489),
                          border: Border.all(
                              width: 1, color: const Color(0xffFF3489))),
                    ),
                    const SizedBox(
                      width: 5,
                    ),
                    const Text(
                      "Ladies",
                      style: TextStyle(
                          fontSize: 10,
                          color: Color(0xff5C5C5C),
                          fontFamily: "Medium"),
                    ),
                  ],
                ),
                Row(
                  children: [
                    Container(
                      width: 25,
                      height: 25,
                      decoration: BoxDecoration(
                          color: const Color(0xff00BA34),
                          border: Border.all(
                              width: 1, color: const Color(0xff00BA34))),
                    ),
                    const SizedBox(
                      width: 5,
                    ),
                    const Text(
                      "Selected",
                      style: TextStyle(
                          fontSize: 10,
                          color: Color(0xff5C5C5C),
                          fontFamily: "Medium"),
                    ),
                  ],
                )
              ],
            ),
            const SizedBox(
              height: 20,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Column(
                  children: [
                    Container(
                      width: MediaQuery.of(context).size.width * 0.45,
                      padding: const EdgeInsets.only(
                          left: 5, right: 5, top: 10, bottom: 10),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          color: Colors.white),
                      child: Column(
                        children: [
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Row(
                                  children: [
                                    Column(
                                      children: [
                                        Container(
                                          width: 25,
                                          alignment: Alignment.center,
                                          child: SvgPicture.asset(
                                            'assets/avail_seat.svg',
                                            width: 25,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(
                                      width: 10,
                                    ),
                                    Column(
                                      children: [
                                        Container(
                                          width: 25,
                                          alignment: Alignment.center,
                                          child: SvgPicture.asset(
                                            'assets/avail_seat.svg',
                                            width: 25,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  width: 30,
                                ),
                                Column(
                                  children: [
                                    Container(
                                      width: 25,
                                      alignment: Alignment.center,
                                      child: SvgPicture.asset(
                                        'assets/avail_seat.svg',
                                        width: 25,
                                        fit: BoxFit.fill,
                                      ),
                                    ),
                                  ],
                                ),
                              ]),
                          const SizedBox(
                            height: 20,
                          ),
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Row(
                                  children: [
                                    Column(
                                      children: [
                                        Container(
                                          width: 25,
                                          alignment: Alignment.center,
                                          child: SvgPicture.asset(
                                            'assets/avail_seat.svg',
                                            width: 25,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(
                                      width: 10,
                                    ),
                                    Column(
                                      children: [
                                        Container(
                                          width: 25,
                                          alignment: Alignment.center,
                                          child: SvgPicture.asset(
                                            'assets/avail_seat.svg',
                                            width: 25,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  width: 30,
                                ),
                                Column(
                                  children: [
                                    Container(
                                      width: 25,
                                      alignment: Alignment.center,
                                      child: SvgPicture.asset(
                                        'assets/selected_seat.svg',
                                        width: 25,
                                        fit: BoxFit.fill,
                                      ),
                                    ),
                                  ],
                                ),
                              ]),
                          const SizedBox(
                            height: 20,
                          ),
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Row(
                                  children: [
                                    Column(
                                      children: [
                                        Container(
                                          width: 25,
                                          alignment: Alignment.center,
                                          child: SvgPicture.asset(
                                            'assets/avail_seat.svg',
                                            width: 25,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(
                                      width: 10,
                                    ),
                                    Column(
                                      children: [
                                        Container(
                                          width: 25,
                                          alignment: Alignment.center,
                                          child: SvgPicture.asset(
                                            'assets/avail_seat.svg',
                                            width: 25,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  width: 30,
                                ),
                                Column(
                                  children: [
                                    Container(
                                      width: 25,
                                      alignment: Alignment.center,
                                      child: SvgPicture.asset(
                                        'assets/ladies_seat.svg',
                                        width: 25,
                                        fit: BoxFit.fill,
                                      ),
                                    ),
                                  ],
                                ),
                              ]),
                          const SizedBox(
                            height: 20,
                          ),
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Row(
                                  children: [
                                    Column(
                                      children: [
                                        Container(
                                          width: 25,
                                          alignment: Alignment.center,
                                          child: SvgPicture.asset(
                                            'assets/avail_seat.svg',
                                            width: 25,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(
                                      width: 10,
                                    ),
                                    Column(
                                      children: [
                                        Container(
                                          width: 25,
                                          alignment: Alignment.center,
                                          child: SvgPicture.asset(
                                            'assets/avail_seat.svg',
                                            width: 25,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  width: 30,
                                ),
                                Column(
                                  children: [
                                    Container(
                                      width: 25,
                                      alignment: Alignment.center,
                                      child: SvgPicture.asset(
                                        'assets/ladies_seat.svg',
                                        width: 25,
                                        fit: BoxFit.fill,
                                      ),
                                    ),
                                  ],
                                ),
                              ]),
                          const SizedBox(
                            height: 20,
                          ),
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Row(
                                  children: [
                                    Column(
                                      children: [
                                        Container(
                                          width: 25,
                                          alignment: Alignment.center,
                                          child: SvgPicture.asset(
                                            'assets/avail_seat.svg',
                                            width: 25,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(
                                      width: 10,
                                    ),
                                    Column(
                                      children: [
                                        Container(
                                          width: 25,
                                          alignment: Alignment.center,
                                          child: SvgPicture.asset(
                                            'assets/avail_seat.svg',
                                            width: 25,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  width: 30,
                                ),
                                Column(
                                  children: [
                                    Container(
                                      width: 25,
                                      alignment: Alignment.center,
                                      child: SvgPicture.asset(
                                        'assets/avail_seat.svg',
                                        width: 25,
                                        fit: BoxFit.fill,
                                      ),
                                    ),
                                  ],
                                ),
                              ]),
                          const SizedBox(
                            height: 20,
                          ),
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Row(
                                  children: [
                                    Column(
                                      children: [
                                        Container(
                                          width: 25,
                                          alignment: Alignment.center,
                                          child: SvgPicture.asset(
                                            'assets/avail_seat.svg',
                                            width: 25,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(
                                      width: 10,
                                    ),
                                    Column(
                                      children: [
                                        Container(
                                          width: 25,
                                          alignment: Alignment.center,
                                          child: SvgPicture.asset(
                                            'assets/avail_seat.svg',
                                            width: 25,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  width: 30,
                                ),
                                Column(
                                  children: [
                                    Container(
                                      width: 25,
                                      alignment: Alignment.center,
                                      child: SvgPicture.asset(
                                        'assets/avail_seat.svg',
                                        width: 25,
                                        fit: BoxFit.fill,
                                      ),
                                    ),
                                  ],
                                ),
                              ]),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 15,
                    ),
                    const Text(
                      "Lower Deck",
                      style: TextStyle(
                          fontSize: 15,
                          color: Colors.black,
                          fontFamily: "Bold"),
                    )
                  ],
                ),
                Column(
                  children: [
                    Container(
                      width: MediaQuery.of(context).size.width * 0.45,
                      padding: const EdgeInsets.only(
                          left: 5, right: 5, top: 10, bottom: 10),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          color: Colors.white),
                      child: Column(
                        children: [
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Row(
                                  children: [
                                    Column(
                                      children: [
                                        Container(
                                          width: 25,
                                          alignment: Alignment.center,
                                          child: SvgPicture.asset(
                                            'assets/selected_seat.svg',
                                            width: 25,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(
                                      width: 10,
                                    ),
                                    Column(
                                      children: [
                                        Container(
                                          width: 25,
                                          alignment: Alignment.center,
                                          child: SvgPicture.asset(
                                            'assets/selected_seat.svg',
                                            width: 25,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  width: 30,
                                ),
                                Column(
                                  children: [
                                    Container(
                                      width: 25,
                                      alignment: Alignment.center,
                                      child: SvgPicture.asset(
                                        'assets/booked_seat.svg',
                                        width: 25,
                                        fit: BoxFit.fill,
                                      ),
                                    ),
                                  ],
                                ),
                              ]),
                          const SizedBox(
                            height: 20,
                          ),
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Row(
                                  children: [
                                    Column(
                                      children: [
                                        Container(
                                          width: 25,
                                          alignment: Alignment.center,
                                          child: SvgPicture.asset(
                                            'assets/avail_seat.svg',
                                            width: 25,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(
                                      width: 10,
                                    ),
                                    Column(
                                      children: [
                                        Container(
                                          width: 25,
                                          alignment: Alignment.center,
                                          child: SvgPicture.asset(
                                            'assets/avail_seat.svg',
                                            width: 25,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  width: 30,
                                ),
                                Column(
                                  children: [
                                    Container(
                                      width: 25,
                                      alignment: Alignment.center,
                                      child: SvgPicture.asset(
                                        'assets/booked_seat.svg',
                                        width: 25,
                                        fit: BoxFit.fill,
                                      ),
                                    ),
                                  ],
                                ),
                              ]),
                          const SizedBox(
                            height: 20,
                          ),
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Row(
                                  children: [
                                    Column(
                                      children: [
                                        Container(
                                          width: 25,
                                          alignment: Alignment.center,
                                          child: SvgPicture.asset(
                                            'assets/avail_seat.svg',
                                            width: 25,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(
                                      width: 10,
                                    ),
                                    Column(
                                      children: [
                                        Container(
                                          width: 25,
                                          alignment: Alignment.center,
                                          child: SvgPicture.asset(
                                            'assets/avail_seat.svg',
                                            width: 25,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  width: 30,
                                ),
                                Column(
                                  children: [
                                    Container(
                                      width: 25,
                                      alignment: Alignment.center,
                                      child: SvgPicture.asset(
                                        'assets/selected_seat.svg',
                                        width: 25,
                                        fit: BoxFit.fill,
                                      ),
                                    ),
                                  ],
                                ),
                              ]),
                          const SizedBox(
                            height: 20,
                          ),
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Row(
                                  children: [
                                    Column(
                                      children: [
                                        Container(
                                          width: 25,
                                          alignment: Alignment.center,
                                          child: SvgPicture.asset(
                                            'assets/avail_seat.svg',
                                            width: 25,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(
                                      width: 10,
                                    ),
                                    Column(
                                      children: [
                                        Container(
                                          width: 25,
                                          alignment: Alignment.center,
                                          child: SvgPicture.asset(
                                            'assets/avail_seat.svg',
                                            width: 25,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  width: 30,
                                ),
                                Column(
                                  children: [
                                    Container(
                                      width: 25,
                                      alignment: Alignment.center,
                                      child: SvgPicture.asset(
                                        'assets/booked_seat.svg',
                                        width: 25,
                                        fit: BoxFit.fill,
                                      ),
                                    ),
                                  ],
                                ),
                              ]),
                          const SizedBox(
                            height: 20,
                          ),
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Row(
                                  children: [
                                    Column(
                                      children: [
                                        Container(
                                          width: 25,
                                          alignment: Alignment.center,
                                          child: SvgPicture.asset(
                                            'assets/selected_seat.svg',
                                            width: 25,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(
                                      width: 10,
                                    ),
                                    Column(
                                      children: [
                                        Container(
                                          width: 25,
                                          alignment: Alignment.center,
                                          child: SvgPicture.asset(
                                            'assets/ladies_seat.svg',
                                            width: 25,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  width: 30,
                                ),
                                Column(
                                  children: [
                                    Container(
                                      width: 25,
                                      alignment: Alignment.center,
                                      child: SvgPicture.asset(
                                        'assets/avail_seat.svg',
                                        width: 25,
                                        fit: BoxFit.fill,
                                      ),
                                    ),
                                  ],
                                ),
                              ]),
                          const SizedBox(
                            height: 20,
                          ),
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Row(
                                  children: [
                                    Column(
                                      children: [
                                        Container(
                                          width: 25,
                                          alignment: Alignment.center,
                                          child: SvgPicture.asset(
                                            'assets/avail_seat.svg',
                                            width: 25,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(
                                      width: 10,
                                    ),
                                    Column(
                                      children: [
                                        Container(
                                          width: 25,
                                          alignment: Alignment.center,
                                          child: SvgPicture.asset(
                                            'assets/avail_seat.svg',
                                            width: 25,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  width: 30,
                                ),
                                Column(
                                  children: [
                                    Container(
                                      width: 25,
                                      alignment: Alignment.center,
                                      child: SvgPicture.asset(
                                        'assets/avail_seat.svg',
                                        width: 25,
                                        fit: BoxFit.fill,
                                      ),
                                    ),
                                  ],
                                ),
                              ]),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 15,
                    ),
                    const Text(
                      "Higher Deck",
                      style: TextStyle(
                          fontSize: 15,
                          color: Colors.black,
                          fontFamily: "Bold"),
                    )
                  ],
                ),
              ],
            )
          ]),
        ),
        Positioned(
            bottom: 0,
            left: 0,
            child: Container(
              width: MediaQuery.of(context).size.width,
              height: 80,
              color: Colors.white,
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        Text(
                          "₹200",
                          style: TextStyle(
                              fontSize: 20,
                              color: Colors.black,
                              fontFamily: "Bold"),
                        ),
                        Text(
                          "Seat A3, D3, F4",
                          style: TextStyle(
                              fontSize: 13,
                              color: Color(0xff5C5C5C),
                              fontFamily: "Medium"),
                        )
                      ],
                    ),
                    InkWell(
                      onTap: () {
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (context) => const Boarding()));
                      },
                      child: Container(
                        padding: const EdgeInsets.only(
                            left: 20, right: 20, top: 10, bottom: 10),
                        decoration: BoxDecoration(
                            color: const Color(0xffFF6A2A),
                            borderRadius: BorderRadius.circular(5)),
                        child: const Text(
                          "Proceed",
                          style: TextStyle(
                              fontSize: 20,
                              color: Colors.white,
                              fontFamily: "Bold"),
                        ),
                      ),
                    )
                  ]),
            ))
      ],
    )));
  }
}
