import 'package:bigbus/calendar.dart';
import 'package:bigbus/from.dart';
import 'package:bigbus/search.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  bool today = true;
  bool tomorrow = false;
  bool ac = false;
  bool nonac = false;
  bool sleeper = false;
  bool seater = false;
  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Colors.white,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
        body: SafeArea(
            child: Container(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
      color: const Color(0xffEFF3F8),
      child: Column(children: [
        Container(
          width: MediaQuery.of(context).size.width,
          height: 100,
          color: Colors.white,
          alignment: Alignment.center,
          margin: const EdgeInsets.only(bottom: 20),
          child: SvgPicture.asset(
            'assets/logo.svg',
            width: 80,
            fit: BoxFit.fill,
          ),
        ),
        Container(
          width: MediaQuery.of(context).size.width * 0.95,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(5),
            color: Colors.white,
          ),
          child: Column(children: [
            const SizedBox(
              height: 20,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                InkWell(
                  onTap: () {
                    Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => const From()));
                  },
                  child: Container(
                    padding: const EdgeInsets.only(left: 20),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text(
                            "From",
                            style: TextStyle(
                                fontSize: 15,
                                color: Color(0xff5C5C5C),
                                fontFamily: "Medium"),
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          Text(
                            "Kolhapur",
                            style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                                fontFamily: "Bold",
                                color: Color(0xff000E2B)),
                          ),
                        ]),
                  ),
                ),
                Container(
                  width: 50,
                  alignment: Alignment.center,
                  child: SvgPicture.asset(
                    'assets/route.svg',
                    width: 25,
                    fit: BoxFit.fill,
                  ),
                ),
                InkWell(
                  onTap: () {
                    Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => const From()));
                  },
                  child: Container(
                    padding: const EdgeInsets.only(right: 20),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: const [
                          Text(
                            "To",
                            style: TextStyle(
                                fontSize: 15,
                                color: Color(0xff5C5C5C),
                                fontFamily: "Medium"),
                          ),
                          Text(
                            "Sangli",
                            style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                                fontFamily: "Bold",
                                color: Color(0xff000E2B)),
                          ),
                        ]),
                  ),
                )
              ],
            ),
            Container(
              margin: const EdgeInsets.only(top: 30),
              width: MediaQuery.of(context).size.width * 0.90,
              height: 1,
              color: const Color(0xffECECEC),
            ),
            const SizedBox(
              height: 20,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                InkWell(
                  onTap: () {
                    Navigator.of(context).push(MaterialPageRoute(
                        builder: (context) => const Calendar()));
                  },
                  child: Container(
                    padding: const EdgeInsets.only(left: 20),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text(
                            "Travel date",
                            style: TextStyle(
                                fontSize: 15,
                                color: Color(0xff5C5C5C),
                                fontFamily: "Medium"),
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          Text(
                            "4 March",
                            style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                                color: Color(0xff000E2B),
                                fontFamily: "Bold"),
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          Text(
                            "Today, Sat",
                            style: TextStyle(
                                fontSize: 15,
                                color: Color(0xff5C5C5C),
                                fontFamily: "Medium"),
                          ),
                        ]),
                  ),
                ),
                Container(
                  margin: const EdgeInsets.only(right: 20),
                  child: Row(
                    children: [
                      InkWell(
                        onTap: () {
                          if (tomorrow) {
                            setState(() {
                              tomorrow = false;
                              today = true;
                            });
                          }
                        },
                        child: Container(
                          width: 80,
                          height: 30,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5),
                              color: today
                                  ? const Color(0xff4A9DFF)
                                  : const Color(0xffEFF3F8)),
                          alignment: Alignment.center,
                          child: Text(
                            "Today",
                            style: TextStyle(
                                fontSize: 13,
                                color: today
                                    ? Colors.white
                                    : const Color(0xff647A97),
                                fontFamily: "SemiBold",
                                fontWeight: FontWeight.w500),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      InkWell(
                        onTap: () {
                          if (today) {
                            setState(() {
                              tomorrow = true;
                              today = false;
                            });
                          }
                        },
                        child: Container(
                          width: 80,
                          height: 30,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5),
                              color: tomorrow
                                  ? const Color(0xff4A9DFF)
                                  : const Color(0xffEFF3F8)),
                          alignment: Alignment.center,
                          child: Text(
                            "Tomorrow",
                            style: TextStyle(
                                fontSize: 13,
                                color: tomorrow
                                    ? Colors.white
                                    : const Color(0xff647A97),
                                fontFamily: "SemiBold",
                                fontWeight: FontWeight.w500),
                          ),
                        ),
                      )
                    ],
                  ),
                )
              ],
            ),
            Container(
              margin: const EdgeInsets.only(top: 20),
              width: MediaQuery.of(context).size.width * 0.90,
              height: 1,
              color: const Color(0xffECECEC),
            ),
            const SizedBox(
              height: 10,
            ),
            Container(
              width: MediaQuery.of(context).size.width * 0.85,
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    const Text(
                      "Travel Preference",
                      style: TextStyle(
                        fontSize: 15,
                        color: Color(0xff5C5C5C),
                        fontFamily: "Medium",
                      ),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        InkWell(
                          onTap: () {
                            if (ac) {
                              setState(() {
                                ac = false;
                              });
                            } else {
                              setState(() {
                                ac = true;
                              });
                            }
                          },
                          child: Container(
                            height: 30,
                            padding: const EdgeInsets.only(left: 15, right: 15),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(5),
                                color: ac
                                    ? const Color(0xff4A9DFF)
                                    : const Color(0xffEFF3F8)),
                            alignment: Alignment.center,
                            child: Text(
                              "AC",
                              style: TextStyle(
                                  fontSize: 13,
                                  color: ac
                                      ? Colors.white
                                      : const Color(0xff647A97),
                                  fontFamily: "SemiBold",
                                  fontWeight: FontWeight.w500),
                            ),
                          ),
                        ),
                        InkWell(
                          onTap: () {
                            if (nonac) {
                              setState(() {
                                nonac = false;
                              });
                            } else {
                              setState(() {
                                nonac = true;
                              });
                            }
                          },
                          child: Container(
                            padding: const EdgeInsets.only(left: 15, right: 15),
                            height: 30,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(5),
                                color: nonac
                                    ? const Color(0xff4A9DFF)
                                    : const Color(0xffEFF3F8)),
                            alignment: Alignment.center,
                            child: Text(
                              "Non-AC",
                              style: TextStyle(
                                  fontSize: 13,
                                  fontFamily: "SemiBold",
                                  color: nonac
                                      ? Colors.white
                                      : const Color(0xff647A97),
                                  fontWeight: FontWeight.w500),
                            ),
                          ),
                        ),
                        InkWell(
                          onTap: () {
                            if (sleeper) {
                              setState(() {
                                sleeper = false;
                              });
                            } else {
                              setState(() {
                                sleeper = true;
                              });
                            }
                          },
                          child: Container(
                            padding: const EdgeInsets.only(left: 15, right: 15),
                            height: 30,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(5),
                                color: sleeper
                                    ? const Color(0xff4A9DFF)
                                    : const Color(0xffEFF3F8)),
                            alignment: Alignment.center,
                            child: Text(
                              "Sleeper",
                              style: TextStyle(
                                  fontSize: 13,
                                  fontFamily: "SemiBold",
                                  color: sleeper
                                      ? Colors.white
                                      : const Color(0xff647A97),
                                  fontWeight: FontWeight.w500),
                            ),
                          ),
                        ),
                        InkWell(
                          onTap: () {
                            if (seater) {
                              setState(() {
                                seater = false;
                              });
                            } else {
                              setState(() {
                                seater = true;
                              });
                            }
                          },
                          child: Container(
                            height: 30,
                            padding: const EdgeInsets.only(left: 15, right: 15),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(5),
                                color: seater
                                    ? const Color(0xff4A9DFF)
                                    : const Color(0xffEFF3F8)),
                            alignment: Alignment.center,
                            child: Text(
                              "Seater",
                              style: TextStyle(
                                  fontSize: 13,
                                  fontFamily: "SemiBold",
                                  color: seater
                                      ? Colors.white
                                      : const Color(0xff647A97),
                                  fontWeight: FontWeight.w500),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                  ]),
            ),
            InkWell(
              onTap: () {
                Navigator.of(context).push(
                    MaterialPageRoute(builder: (context) => const Search()));
              },
              child: Container(
                width: MediaQuery.of(context).size.width * 0.85,
                height: 40,
                margin: const EdgeInsets.only(bottom: 20),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    color: const Color(0xffFF6A2A)),
                alignment: Alignment.center,
                child: const Text(
                  "Find Buses",
                  style: TextStyle(
                      fontSize: 15,
                      color: Colors.white,
                      fontFamily: "SemiBold",
                      fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ]),
        ),
        Container(
          width: MediaQuery.of(context).size.width * 0.95,
          padding: const EdgeInsets.only(top: 15, bottom: 15),
          margin: const EdgeInsets.only(top: 20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(5),
            color: Colors.white,
          ),
          alignment: Alignment.center,
          child:
              Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
            Column(
              children: [
                SvgPicture.asset(
                  'assets/tickets.svg',
                  width: 30,
                  fit: BoxFit.fill,
                ),
                const SizedBox(
                  height: 5,
                ),
                const Text(
                  "My Tickets",
                  style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                      fontFamily: "Bold",
                      color: Color(0xff525252)),
                )
              ],
            ),
            Column(
              children: [
                SvgPicture.asset(
                  'assets/contact.svg',
                  width: 30,
                  fit: BoxFit.fill,
                ),
                const SizedBox(
                  height: 5,
                ),
                const Text(
                  "Help",
                  style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                      fontFamily: "Bold",
                      color: Color(0xff525252)),
                )
              ],
            ),
            Column(
              children: [
                SvgPicture.asset(
                  'assets/account.svg',
                  width: 30,
                  fit: BoxFit.fill,
                ),
                const SizedBox(
                  height: 5,
                ),
                const Text(
                  "Account",
                  style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                      fontFamily: "Bold",
                      color: Color(0xff525252)),
                )
              ],
            ),
          ]),
        )
      ]),
    )));
  }
}
