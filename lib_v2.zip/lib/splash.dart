import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';

class Splash extends StatefulWidget {
  const Splash({super.key});

  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xffFF6A2A),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
        backgroundColor: const Color(0xffFF6A2A),
        body: SafeArea(
            child: Stack(
          children: [
            SizedBox(
              width: MediaQuery.of(context).size.width,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.30,
                  ),
                  SvgPicture.asset(
                    'assets/logo.svg',
                    width: 100,
                    fit: BoxFit.fill,
                  ),
                ],
              ),
            ),
            Positioned(
                bottom: 0,
                child: SizedBox(
                  width: MediaQuery.of(context).size.width,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      SvgPicture.asset(
                        'assets/bus_stop.svg',
                        width: MediaQuery.of(context).size.width * 0.70,
                        fit: BoxFit.fill,
                      ),
                      const SizedBox(
                        height: 30,
                      ),
                      const Text(
                        "100% Safe and Secure",
                        style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                            fontFamily: "Bold",
                            color: Colors.white),
                      ),
                      const SizedBox(
                        height: 50,
                      ),
                    ],
                  ),
                )),
          ],
        )));
  }
}
