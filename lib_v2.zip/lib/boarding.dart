import 'package:bigbus/droping.dart';
import 'package:bigbus/home.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';

class Boarding extends StatefulWidget {
  const Boarding({super.key});

  @override
  State<Boarding> createState() => _BoardingState();
}

class _BoardingState extends State<Boarding> {
  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff4A9DFF),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
        body: SafeArea(
            child: Container(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
      color: const Color(0xffEFF3F8),
      child: Column(children: [
        Container(
            width: MediaQuery.of(context).size.width,
            height: 80,
            color: const Color(0xff4A9DFF),
            alignment: Alignment.center,
            child: Row(
              children: [
                const SizedBox(
                  width: 10,
                ),
                InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: SvgPicture.asset(
                    'assets/back.svg',
                    width: 30,
                    fit: BoxFit.fill,
                  ),
                ),
                const SizedBox(
                  width: 10,
                ),
                const Text(
                  "Select Boarding Point",
                  style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      fontFamily: "Bold",
                      color: Colors.white),
                ),
              ],
            )),
        InkWell(
          onTap: () {
            Navigator.of(context).push(
                MaterialPageRoute(builder: (context) => const Dropping()));
          },
          child: Container(
            width: MediaQuery.of(context).size.width,
            color: Colors.white,
            padding: const EdgeInsets.all(15),
            margin: const EdgeInsets.only(top: 10),
            child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.60,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: const [
                        Text(
                          "Paldi",
                          style: TextStyle(
                              fontSize: 15,
                              color: Color(0xff000E2B),
                              fontFamily: "Bold"),
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        Text(
                          "zingbus Lounge Paldi, Landmark:Paldi",
                          style: TextStyle(
                              fontSize: 10,
                              color: Color(0xff848484),
                              fontFamily: "Medium"),
                        ),
                      ],
                    ),
                  ),
                  const Text(
                    "09:05PM",
                    style: TextStyle(
                        fontSize: 15,
                        color: Color(0xff000E2B),
                        fontFamily: "Bold"),
                  ),
                ]),
          ),
        ),
        Container(
          width: MediaQuery.of(context).size.width,
          color: Colors.white,
          padding: const EdgeInsets.all(15),
          margin: const EdgeInsets.only(top: 10),
          child:
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            SizedBox(
              width: MediaQuery.of(context).size.width * 0.60,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text(
                    "Sattellite Eagle Connect Novex",
                    style: TextStyle(
                        fontSize: 15,
                        color: Color(0xff000E2B),
                        fontFamily: "Bold"),
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Text(
                    "Iscon SG Highway Near GSRTC Bus Stand, Landmark:Iscon SG Highway Near GSRTC Bus Stand",
                    style: TextStyle(
                        fontSize: 10,
                        color: Color(0xff848484),
                        fontFamily: "Medium"),
                  ),
                ],
              ),
            ),
            const Text(
              "09:05PM",
              style: TextStyle(
                  fontSize: 15, color: Color(0xff000E2B), fontFamily: "Bold"),
            ),
          ]),
        ),
      ]),
    )));
  }
}
