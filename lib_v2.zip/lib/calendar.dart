import 'package:bigbus/home.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:paged_vertical_calendar/paged_vertical_calendar.dart';
import 'package:intl/intl.dart';

class Calendar extends StatefulWidget {
  const Calendar({super.key});

  @override
  State<Calendar> createState() => _CalendarState();
}

class _CalendarState extends State<Calendar> {
  /// store the selected start and end dates
  DateTime? start;

  /// method to check wether a day is in the selected range
  /// used for highlighting those day
  bool isInRange(DateTime date) {
    // if start is null, no date has been selected yet
    if (start == null) return false;
    // if both start and end aren't null check if date false in the range
    return ((date == start));
  }

  bool isMin(DateTime date) {
    // if start is null, no date has been selected yet
    if (int.parse(DateFormat('M').format(date)) ==
        int.parse(DateFormat('M').format(DateTime.now()))) {
      if (int.parse(DateFormat('d').format(date)) <=
          int.parse(DateFormat('d').format(DateTime.now()))) {
        return false;
      }
    }

    return true;
    // if both start and end aren't null check if date false in the range
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff4A9DFF),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
        body: SafeArea(
            child: Container(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
      color: const Color(0xffEFF3F8),
      child: Column(children: [
        Container(
            width: MediaQuery.of(context).size.width,
            height: 80,
            color: const Color(0xff4A9DFF),
            alignment: Alignment.center,
            margin: const EdgeInsets.only(bottom: 20),
            child: Row(
              children: [
                const SizedBox(
                  width: 10,
                ),
                InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: SvgPicture.asset(
                    'assets/back.svg',
                    width: 30,
                    fit: BoxFit.fill,
                  ),
                ),
                const SizedBox(
                  width: 10,
                ),
                const Text(
                  "Pick your Journey date",
                  style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      fontFamily: "Bold",
                      color: Colors.white),
                ),
              ],
            )),
        Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height - 150,
          child: PagedVerticalCalendar(
            minDate: DateTime.now(),
            initialDate: DateTime.now(),
            addAutomaticKeepAlives: true,
            dayBuilder: (context, date) {
              // update the days color based on if it's selected or not

              final color = isInRange(date)
                  ? const Color(0xffFF6A2A)
                  : isMin(date)
                      ? Colors.white
                      : Color.fromARGB(255, 214, 214, 214);
              Colors.white;
              final txtcolor = isInRange(date)
                  ? Colors.white
                  : isMin(date)
                      ? const Color(0xff5C5C5C)
                      : Color.fromARGB(255, 145, 145, 145);

              return Container(
                decoration: BoxDecoration(
                    color: color,
                    border: Border.all(
                        width: 1,
                        color: const Color.fromARGB(255, 241, 241, 241))),
                child: Center(
                  child: Text(
                    DateFormat('d').format(date),
                    style: TextStyle(
                        fontSize: 13, fontFamily: "SemiBold", color: txtcolor),
                  ),
                ),
              );
            },
            onDayPressed: (date) {
              if (isMin(date)) {
                setState(() {
                  if (start == null) {
                    start = date;
                  } else {
                    print('selected range from $start');
                    start = null;
                  }
                });
                Navigator.of(context).push(
                    MaterialPageRoute(builder: (context) => const Home()));
              }
            },
          ),
        ),
      ]),
    )));
  }
}
