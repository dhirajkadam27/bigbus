import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';

class From extends StatefulWidget {
  const From({super.key});

  @override
  State<From> createState() => _FromState();
}

class _FromState extends State<From> {
  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff4A9DFF),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
        body: SafeArea(
            child: Container(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
      color: const Color(0xffEFF3F8),
      child: Column(children: [
        Container(
            width: MediaQuery.of(context).size.width,
            height: 80,
            color: const Color(0xff4A9DFF),
            alignment: Alignment.center,
            margin: const EdgeInsets.only(bottom: 20),
            child: Row(
              children: [
                const SizedBox(
                  width: 10,
                ),
                InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: SvgPicture.asset(
                    'assets/back.svg',
                    width: 30,
                    fit: BoxFit.fill,
                  ),
                ),
                const SizedBox(
                  width: 10,
                ),
                Container(
                  width: MediaQuery.of(context).size.width * 0.80,
                  height: 50,
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(5)),
                )
              ],
            )),
        Container(
          width: MediaQuery.of(context).size.width * 0.95,
          decoration: BoxDecoration(
              color: Colors.white, borderRadius: BorderRadius.circular(5)),
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Padding(
              padding: EdgeInsets.only(top: 15, bottom: 15, left: 15),
              child: Text(
                "Surat, Gujarat",
                style: TextStyle(
                    fontSize: 15,
                    color: Color(0xff404040),
                    fontFamily: "SemiBold"),
              ),
            ),
            Container(
              width: MediaQuery.of(context).size.width * 0.95,
              height: 1,
              color: const Color(0xffECECEC),
            ),
            const Padding(
              padding: EdgeInsets.only(top: 15, bottom: 15, left: 15),
              child: Text(
                "Delhi Gate, Surat",
                style: TextStyle(
                    fontSize: 15,
                    color: Color(0xff404040),
                    fontFamily: "SemiBold"),
              ),
            ),
          ]),
        )
      ]),
    )));
  }
}
